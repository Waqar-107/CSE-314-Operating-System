#define FOR(i,n) for(i=0;i<n;i++)
#define PB push_back
#define SORT(A) sort(A.begin(),A.end())
#define DEL(A,i) A.erase(A.begin()+i);


#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>

using namespace std;
int main(void)
{
    ios::sync_with_stdio(0);
    return 0;
}

